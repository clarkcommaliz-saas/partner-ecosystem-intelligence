"""
SaaS Partner Ecosystem Tracker
================================
Author: [Your Name]
Purpose: Market intelligence tool for analyzing and comparing partner program
         structures across major SaaS and cloud ecosystems. Built to support
         strategic partnership decisions including ISV prioritization, ecosystem
         entry strategy, and competitive partner landscape analysis.

Target ecosystems: Salesforce, AWS, Azure, HubSpot, Slack
"""

import csv
import json
from datetime import datetime


# ─────────────────────────────────────────────
# ECOSYSTEM DATA
# Each entry reflects publicly available program
# details scored across 6 dimensions (0–100).
# ─────────────────────────────────────────────

ECOSYSTEMS = [
    {
        "name": "Salesforce",
        "type": "CRM / Cloud Platform",
        "tiers": ["Registered", "Silver", "Gold", "Platinum", "Global Strategic"],
        "marketplace": "AppExchange",
        "marketplace_listings": 8000,
        "scores": {
            "tier_structure_clarity":     95,
            "co_sell_co_market_support":  90,
            "marketplace_presence":       98,
            "isv_technical_resources":    88,
            "revenue_share_attractiveness": 82,
            "partner_portal_quality":     92,
        },
        "highlights": [
            "AppExchange: largest SaaS marketplace (8,000+ listings)",
            "ISV royalty program with revenue share",
            "Trailhead partner learning paths",
            "Co-innovation labs for enterprise ISVs",
        ],
        "strategic_notes": (
            "Best-in-class marketplace and ISV ecosystem. High barrier to entry "
            "at upper tiers but strong revenue upside. Ideal for B2B SaaS companies "
            "targeting mid-market and enterprise CRM users."
        ),
    },
    {
        "name": "AWS",
        "type": "Cloud Infrastructure",
        "tiers": ["Registered", "Select", "Advanced", "Premier"],
        "marketplace": "AWS Marketplace",
        "marketplace_listings": 15000,
        "scores": {
            "tier_structure_clarity":     85,
            "co_sell_co_market_support":  92,
            "marketplace_presence":       95,
            "isv_technical_resources":    94,
            "revenue_share_attractiveness": 80,
            "partner_portal_quality":     86,
        },
        "highlights": [
            "AWS Marketplace: 15,000+ software listings",
            "ISV Accelerate co-sell program with AWS field team",
            "Dedicated Partner Development Managers (PDMs)",
            "Marketing Development Funds (MDF) available",
        ],
        "strategic_notes": (
            "Strongest co-sell motion in cloud. ISV Accelerate program is highly "
            "valued by SaaS partners for pipeline generation. Best fit for "
            "infrastructure-adjacent or cloud-native ISVs."
        ),
    },
    {
        "name": "Azure (Microsoft)",
        "type": "Cloud Infrastructure",
        "tiers": ["Member", "Action Pack", "Silver", "Gold"],
        "marketplace": "Azure Marketplace",
        "marketplace_listings": 10000,
        "scores": {
            "tier_structure_clarity":     80,
            "co_sell_co_market_support":  90,
            "marketplace_presence":       88,
            "isv_technical_resources":    90,
            "revenue_share_attractiveness": 78,
            "partner_portal_quality":     82,
        },
        "highlights": [
            "Azure Marketplace with 10,000+ solutions",
            "Co-sell ready status unlocks Microsoft field engagement",
            "ISV Success program with engineering support",
            "Microsoft for Startups (Founders Hub)",
        ],
        "strategic_notes": (
            "Strong enterprise GTM via Microsoft sales team. Co-sell program rivals "
            "AWS. Ideal for ISVs targeting enterprise accounts, especially those "
            "already embedded in Microsoft 365 / Teams ecosystem."
        ),
    },
    {
        "name": "HubSpot",
        "type": "CRM / Marketing Platform",
        "tiers": ["Gold", "Platinum", "Diamond", "Elite"],
        "marketplace": "App Marketplace",
        "marketplace_listings": 1500,
        "scores": {
            "tier_structure_clarity":     88,
            "co_sell_co_market_support":  72,
            "marketplace_presence":       80,
            "isv_technical_resources":    75,
            "revenue_share_attractiveness": 85,
            "partner_portal_quality":     78,
        },
        "highlights": [
            "App Marketplace with 1,500+ integrations",
            "Solutions Partner Program (agency + ISV)",
            "Attractive revenue share model",
            "HubSpot Academy for partner enablement",
        ],
        "strategic_notes": (
            "Strong SMB and mid-market ecosystem. More accessible for early-stage "
            "ISVs than Salesforce. Revenue share is attractive; co-sell motion "
            "still maturing compared to Salesforce or AWS."
        ),
    },
    {
        "name": "Slack",
        "type": "Collaboration / Messaging",
        "tiers": ["App Directory", "Certified App", "Built on Slack"],
        "marketplace": "App Directory",
        "marketplace_listings": 2600,
        "scores": {
            "tier_structure_clarity":     70,
            "co_sell_co_market_support":  68,
            "marketplace_presence":       82,
            "isv_technical_resources":    80,
            "revenue_share_attractiveness": 60,
            "partner_portal_quality":     74,
        },
        "highlights": [
            "App Directory with 2,600+ apps",
            "Workflow Builder for no-code integrations",
            "Bolt SDK for rapid app development",
            "Salesforce acquisition creates cross-sell opportunity",
        ],
        "strategic_notes": (
            "Post-Salesforce acquisition the program is still evolving. Strong "
            "developer tools and high user distribution, but the formal partnership "
            "program is less mature. Best for ISVs already in the Salesforce ecosystem."
        ),
    },
]


# ─────────────────────────────────────────────
# SCORING ENGINE
# ─────────────────────────────────────────────

def calculate_overall_score(ecosystem):
    """Calculate a weighted overall score from dimension scores."""
    weights = {
        "tier_structure_clarity":       0.15,
        "co_sell_co_market_support":    0.25,   # highest weight: drives revenue
        "marketplace_presence":         0.20,
        "isv_technical_resources":      0.15,
        "revenue_share_attractiveness": 0.15,
        "partner_portal_quality":       0.10,
    }
    scores = ecosystem["scores"]
    total = sum(scores[dim] * weight for dim, weight in weights.items())
    return round(total, 1)


def rank_ecosystems(ecosystems):
    """Return ecosystems sorted by overall score descending."""
    ranked = []
    for eco in ecosystems:
        eco_copy = dict(eco)
        eco_copy["overall_score"] = calculate_overall_score(eco)
        ranked.append(eco_copy)
    return sorted(ranked, key=lambda x: x["overall_score"], reverse=True)


def find_best_in_dimension(ecosystems, dimension):
    """Return the ecosystem name with the highest score in a given dimension."""
    best = max(ecosystems, key=lambda e: e["scores"].get(dimension, 0))
    return best["name"]


# ─────────────────────────────────────────────
# REPORT PRINTER
# ─────────────────────────────────────────────

DIVIDER = "─" * 65

def print_header():
    print(f"\n{'═' * 65}")
    print("  SAAS PARTNER ECOSYSTEM TRACKER")
    print(f"  Market Intelligence Report  |  {datetime.now().strftime('%B %d, %Y')}")
    print(f"{'═' * 65}\n")


def print_rankings(ranked):
    print("  OVERALL ECOSYSTEM RANKINGS  (weighted score / 100)\n")
    for i, eco in enumerate(ranked, 1):
        bar_len = int(eco["overall_score"] / 5)
        bar = "█" * bar_len
        print(f"  {i}. {eco['name']:<22} {eco['overall_score']:>5}  {bar}")
    print(f"\n  Weighting: co-sell support 25% | marketplace 20% |")
    print(f"  tier clarity 15% | tech resources 15% | rev share 15% | portal 10%")


def print_dimension_leaders(ecosystems):
    print(f"\n{DIVIDER}")
    print("  LEADERS BY DIMENSION\n")
    dimensions = {
        "tier_structure_clarity":       "Tier structure clarity",
        "co_sell_co_market_support":    "Co-sell / co-market support",
        "marketplace_presence":         "Marketplace presence",
        "isv_technical_resources":      "ISV technical resources",
        "revenue_share_attractiveness": "Revenue share attractiveness",
        "partner_portal_quality":       "Partner portal quality",
    }
    for key, label in dimensions.items():
        leader = find_best_in_dimension(ecosystems, key)
        score = max(e["scores"][key] for e in ecosystems if e["name"] == leader)
        print(f"  {label:<35} → {leader} ({score})")


def print_ecosystem_profiles(ranked):
    print(f"\n{DIVIDER}")
    print("  ECOSYSTEM PROFILES\n")
    for eco in ranked:
        print(f"  ▸ {eco['name']}  [{eco['type']}]")
        print(f"    Overall score : {eco['overall_score']}/100")
        print(f"    Marketplace   : {eco['marketplace']} ({eco['marketplace_listings']:,} listings)")
        print(f"    Tiers         : {' → '.join(eco['tiers'])}")
        print(f"    Strategy note : {eco['strategic_notes'][:120]}...")
        print()


def print_comparison_table(ecosystems):
    dims = list(ecosystems[0]["scores"].keys())
    dim_labels = [d.replace("_", " ").title()[:22] for d in dims]

    print(f"\n{DIVIDER}")
    print("  DIMENSION COMPARISON TABLE\n")

    # Header row
    header = f"  {'Dimension':<28}" + "".join(f"{e['name'][:10]:<12}" for e in ecosystems)
    print(header)
    print("  " + "─" * (26 + 12 * len(ecosystems)))

    for dim, label in zip(dims, dim_labels):
        vals = [e["scores"][dim] for e in ecosystems]
        best = max(vals)
        row = f"  {label:<28}"
        for v in vals:
            marker = "★" if v == best else " "
            row += f"{v}{marker:<11}"
        print(row)

    print(f"\n  ★ = highest score in dimension")


# ─────────────────────────────────────────────
# CSV EXPORT
# ─────────────────────────────────────────────

def export_to_csv(ranked, filename=None):
    if filename is None:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M")
        filename = f"partner_ecosystem_report_{timestamp}.csv"

    fieldnames = (
        ["name", "type", "overall_score", "marketplace", "marketplace_listings"]
        + list(ranked[0]["scores"].keys())
        + ["strategic_notes"]
    )

    with open(filename, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for eco in ranked:
            row = {
                "name":                   eco["name"],
                "type":                   eco["type"],
                "overall_score":          eco["overall_score"],
                "marketplace":            eco["marketplace"],
                "marketplace_listings":   eco["marketplace_listings"],
                "strategic_notes":        eco["strategic_notes"],
            }
            row.update(eco["scores"])
            writer.writerow(row)

    print(f"\n  ✓ Report exported → {filename}")
    return filename


def export_to_json(ranked, filename=None):
    if filename is None:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M")
        filename = f"partner_ecosystem_report_{timestamp}.json"

    export_data = {
        "generated_at": datetime.now().isoformat(),
        "ecosystems": [
            {k: v for k, v in eco.items() if k != "scores"}
            | {"scores": eco["scores"], "overall_score": eco["overall_score"]}
            for eco in ranked
        ]
    }

    with open(filename, "w", encoding="utf-8") as f:
        json.dump(export_data, f, indent=2)

    print(f"  ✓ JSON exported  → {filename}")
    return filename


# ─────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────

def main():
    ranked = rank_ecosystems(ECOSYSTEMS)

    print_header()
    print_rankings(ranked)
    print_dimension_leaders(ECOSYSTEMS)
    print_ecosystem_profiles(ranked)
    print_comparison_table(ranked)

    print(f"\n{DIVIDER}")
    export_to_csv(ranked)
    export_to_json(ranked)
    print(f"\n{'═' * 65}\n")


if __name__ == "__main__":
    main()
