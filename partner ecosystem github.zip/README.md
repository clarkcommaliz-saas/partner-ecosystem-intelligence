# SaaS Partner Ecosystem Tracker

A market intelligence tool for analyzing and comparing partner program structures across major SaaS and cloud platforms — built from a **strategic partnerships perspective**.

---

## What This Does

This tool scores and ranks five major partner ecosystems — Salesforce, AWS, Azure, HubSpot, and Slack — across the dimensions that actually matter when evaluating where to invest as an ISV or technology partner:

- **Co-sell / co-market support** — does the platform's sales team actively bring partners into deals?
- **Marketplace presence** — how large and discoverable is the partner marketplace?
- **Tier structure clarity** — are the requirements and benefits of each tier clearly defined?
- **ISV technical resources** — what SDKs, APIs, sandbox environments, and engineering support exist?
- **Revenue share attractiveness** — what is the economic upside for a partner?
- **Partner portal quality** — how well does the platform support day-to-day partner operations?

Outputs a ranked report to the terminal and exports both CSV and JSON files for further analysis.

---

## Sample Output

```
═════════════════════════════════════════════════════════════════
  SAAS PARTNER ECOSYSTEM TRACKER
  Market Intelligence Report  |  March 2025
═════════════════════════════════════════════════════════════════

  OVERALL ECOSYSTEM RANKINGS  (weighted score / 100)

  1. Salesforce             91.0  ██████████████████
  2. AWS                    89.1  █████████████████
  3. Azure (Microsoft)      85.5  █████████████████
  4. HubSpot                78.8  ███████████████
  5. Slack                  73.1  ██████████████

  LEADERS BY DIMENSION

  Tier structure clarity              → Salesforce (95)
  Co-sell / co-market support         → AWS (92)
  Marketplace presence                → Salesforce (98)
  ISV technical resources             → AWS (94)
  Revenue share attractiveness        → Salesforce (82)
  Partner portal quality              → Salesforce (92)
```

---

## How to Run

**Requirements:** Python 3.7+, no external dependencies.

```bash
# Clone the repo
git clone https://github.com/YOUR-USERNAME/partner-ecosystem-intelligence.git
cd partner-ecosystem-intelligence

# Run the tracker
python partner_tracker.py
```

Two files will be generated in your working directory:
- `partner_ecosystem_report_YYYYMMDD_HHMM.csv` — open in Excel or Google Sheets
- `partner_ecosystem_report_YYYYMMDD_HHMM.json` — for downstream data use

---

## Scoring Methodology

Each ecosystem is scored 0–100 across six dimensions based on publicly available program documentation, marketplace data, and partner program terms. An overall weighted score is calculated as follows:

| Dimension | Weight | Rationale |
|---|---|---|
| Co-sell / co-market support | 25% | Most direct driver of partner-sourced pipeline |
| Marketplace presence | 20% | Distribution reach for ISV listings |
| Tier structure clarity | 15% | Predictability of program requirements and benefits |
| ISV technical resources | 15% | Depth of developer tools and support |
| Revenue share attractiveness | 15% | Economic viability for partners |
| Partner portal quality | 10% | Operational efficiency for day-to-day management |

> Scores are based on program analysis as of Q1 2025. Partner programs change frequently — treat this as a starting framework, not a definitive ranking.

---

## Extending This Tool

The data lives in a single `ECOSYSTEMS` list at the top of `partner_tracker.py`. To add or update an ecosystem:

```python
{
    "name": "Google Cloud",
    "type": "Cloud Infrastructure",
    "tiers": ["Member", "Partner", "Premier"],
    "marketplace": "Google Cloud Marketplace",
    "marketplace_listings": 3000,
    "scores": {
        "tier_structure_clarity":       80,
        "co_sell_co_market_support":    85,
        "marketplace_presence":         82,
        "isv_technical_resources":      90,
        "revenue_share_attractiveness": 75,
        "partner_portal_quality":       78,
    },
    "highlights": [...],
    "strategic_notes": "...",
}
```

---

## Why I Built This

As a partnerships professional, I've spent years evaluating which ecosystems to invest in — and that decision is rarely made with structured data. Most partner managers rely on tribal knowledge, vendor marketing, or anecdotal peer feedback.

This tool is an attempt to make that evaluation more systematic. The scoring framework reflects how I actually think about ecosystem value: co-sell motion and marketplace distribution matter more than tier names or logo placement.

**Intended audience:** ISV partner managers, technology partnership leads, and BD professionals evaluating ecosystem strategy.

---

## About

Built as part of a technical partnerships portfolio demonstrating the intersection of strategic partnerships knowledge and technical curiosity.

- **Author:** [Your Name]
- **LinkedIn:** [Your LinkedIn URL]
- **Focus areas:** ISV partnerships, technology alliances, SaaS ecosystem strategy

---

*Data sourced from public partner program documentation. Not affiliated with any of the platforms listed.*
